# Bucket 1 Summary

- **Range**: [2, 2]
- **Total tested**: 1
- **Primes**: 1 (known: 1, new: 0)
- **Composites**: 0
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (1)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 2 | GenericBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 2 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
