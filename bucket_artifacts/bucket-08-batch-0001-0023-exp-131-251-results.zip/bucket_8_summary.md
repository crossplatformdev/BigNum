# Bucket 8 Summary

- **Range**: [128, 255]
- **Total tested**: 23
- **Primes**: 0 (known: 0, new: 0)
- **Composites**: 23
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (0)

_None in this bucket._

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 131 | composite | LimbBackend | 0.000 | `ce3c8d1bf6df73b7` | no | no |
| 137 | composite | LimbBackend | 0.000 | `c20b8da07aedff68` | no | no |
| 139 | composite | LimbBackend | 0.000 | `0e8d6fdedff25604` | no | no |
| 149 | composite | LimbBackend | 0.000 | `a3ac59ea95df097f` | no | no |
| 151 | composite | LimbBackend | 0.000 | `0492c6696cad7fee` | no | no |
| 157 | composite | LimbBackend | 0.000 | `d18e9d152f805445` | no | no |
| 163 | composite | LimbBackend | 0.000 | `cebb4d0306874f7e` | no | no |
| 167 | composite | LimbBackend | 0.000 | `00f0c91e572b2814` | no | no |
| 173 | composite | LimbBackend | 0.000 | `124892fba3970526` | no | no |
| 179 | composite | LimbBackend | 0.000 | `b2705264916deaf4` | no | no |
| 181 | composite | LimbBackend | 0.000 | `9306112c8c7e6838` | no | no |
| 191 | composite | LimbBackend | 0.000 | `a383e7c9f0958e51` | no | no |
| 193 | composite | LimbBackend | 0.000 | `40d55b955ecf0cf2` | no | no |
| 197 | composite | LimbBackend | 0.000 | `6db1f6f3077e09ef` | no | no |
| 199 | composite | LimbBackend | 0.000 | `d2a80a172d1e6ec7` | no | no |
| 211 | composite | LimbBackend | 0.000 | `6bca2829bceaaa98` | no | no |
| 223 | composite | LimbBackend | 0.000 | `260bbac39e1cb93b` | no | no |
| 227 | composite | LimbBackend | 0.000 | `7fb7ae36eb26e7ce` | no | no |
| 229 | composite | LimbBackend | 0.000 | `98d48bb7402357f3` | no | no |
| 233 | composite | LimbBackend | 0.000 | `e6cf129d5380a0fc` | no | no |
| 239 | composite | LimbBackend | 0.000 | `74fbd8a0055a9377` | no | no |
| 241 | composite | LimbBackend | 0.000 | `847cd07e1ee565e7` | no | no |
| 251 | composite | LimbBackend | 0.000 | `8f5a3d3ebbfd8554` | no | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
