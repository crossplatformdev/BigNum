# Bucket 5 Summary

- **Range**: [16, 31]
- **Total tested**: 5
- **Primes**: 3 (known: 3, new: 0)
- **Composites**: 2
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (3)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 17 | GenericBackend | 0.000 | `0000000000000000` |
| 19 | GenericBackend | 0.000 | `0000000000000000` |
| 31 | GenericBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 17 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |
| 19 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |
| 23 | composite | GenericBackend | 0.000 | `00000000005d32f7` | no | no |
| 29 | composite | GenericBackend | 0.000 | `000000001b57cb0b` | no | no |
| 31 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
