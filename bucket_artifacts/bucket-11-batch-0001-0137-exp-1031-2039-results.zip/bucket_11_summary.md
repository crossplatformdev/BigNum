# Bucket 11 Summary

- **Range**: [1024, 2047]
- **Total tested**: 137
- **Primes**: 1 (known: 1, new: 0)
- **Composites**: 136
- **Total time**: 0.276 s
- **Avg time**: 0.002 s/exponent

## Verified Known Mersenne Primes (1)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 1279 | LimbBackend | 0.001 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 1031 | composite | LimbBackend | 0.001 | `de5d9e92c99878f7` | no | no |
| 1033 | composite | LimbBackend | 0.001 | `8ec66449f53bc155` | no | no |
| 1039 | composite | LimbBackend | 0.001 | `9a3d0cd78abebaea` | no | no |
| 1049 | composite | LimbBackend | 0.001 | `6fc61883a8579b01` | no | no |
| 1051 | composite | LimbBackend | 0.001 | `5794a4656af7cb33` | no | no |
| 1061 | composite | LimbBackend | 0.001 | `7904a8672061516e` | no | no |
| 1063 | composite | LimbBackend | 0.001 | `68562e0967c9b634` | no | no |
| 1069 | composite | LimbBackend | 0.001 | `bc1094d73702ac31` | no | no |
| 1087 | composite | LimbBackend | 0.001 | `a5c11b63ab592d9f` | no | no |
| 1091 | composite | LimbBackend | 0.001 | `34abd421b64cbfd9` | no | no |
| 1093 | composite | LimbBackend | 0.001 | `079f702bf9655ade` | no | no |
| 1097 | composite | LimbBackend | 0.001 | `37c96b625e249163` | no | no |
| 1103 | composite | LimbBackend | 0.001 | `41f5247161f44228` | no | no |
| 1109 | composite | LimbBackend | 0.001 | `cd0f83db351bee84` | no | no |
| 1117 | composite | LimbBackend | 0.001 | `61411631f56a3bfd` | no | no |
| 1123 | composite | LimbBackend | 0.001 | `418b6e94cbf725c7` | no | no |
| 1129 | composite | LimbBackend | 0.001 | `fcfff6180a6e4939` | no | no |
| 1151 | composite | LimbBackend | 0.001 | `edb4e35f3172cee2` | no | no |
| 1153 | composite | LimbBackend | 0.001 | `52140ea34ffff797` | no | no |
| 1163 | composite | LimbBackend | 0.001 | `ea487b17e04bcf7e` | no | no |
| 1171 | composite | LimbBackend | 0.001 | `6665e3949dfe0408` | no | no |
| 1181 | composite | LimbBackend | 0.001 | `87a110fda891e8b8` | no | no |
| 1187 | composite | LimbBackend | 0.001 | `0047b497c7b404a4` | no | no |
| 1193 | composite | LimbBackend | 0.001 | `3932a534e7da56f2` | no | no |
| 1201 | composite | LimbBackend | 0.001 | `0129c9f02b5076f7` | no | no |
| 1213 | composite | LimbBackend | 0.001 | `16f1cb9935bc16ae` | no | no |
| 1217 | composite | LimbBackend | 0.001 | `f257bb1620f97d8b` | no | no |
| 1223 | composite | LimbBackend | 0.001 | `d2f0cd0456dd783b` | no | no |
| 1229 | composite | LimbBackend | 0.001 | `09f25544ecc8573a` | no | no |
| 1231 | composite | LimbBackend | 0.001 | `4df4ebf3bf1639b8` | no | no |
| 1237 | composite | LimbBackend | 0.001 | `df5e6622f83f5be2` | no | no |
| 1249 | composite | LimbBackend | 0.001 | `125aae8ad116621b` | no | no |
| 1259 | composite | LimbBackend | 0.001 | `2085b5a3a32e5ca9` | no | no |
| 1277 | composite | LimbBackend | 0.001 | `5613a480590e78ba` | no | no |
| 1279 | prime | LimbBackend | 0.001 | `0000000000000000` | yes | no |
| 1283 | composite | LimbBackend | 0.001 | `b1b97600f4c17a1a` | no | no |
| 1289 | composite | LimbBackend | 0.001 | `8cb68647624c6ae7` | no | no |
| 1291 | composite | LimbBackend | 0.001 | `446a5c3ee516625f` | no | no |
| 1297 | composite | LimbBackend | 0.001 | `c5c1105c47ffa5d5` | no | no |
| 1301 | composite | LimbBackend | 0.001 | `66afdde8adc140a1` | no | no |
| 1303 | composite | LimbBackend | 0.001 | `423af4faf8257f31` | no | no |
| 1307 | composite | LimbBackend | 0.001 | `ea50d49774dc062b` | no | no |
| 1319 | composite | LimbBackend | 0.001 | `a5b1054f902c320c` | no | no |
| 1321 | composite | LimbBackend | 0.001 | `cf6bb7f76fed17a8` | no | no |
| 1327 | composite | LimbBackend | 0.001 | `9d922d6c22bd7b78` | no | no |
| 1361 | composite | LimbBackend | 0.001 | `8c15daf2a802e2e2` | no | no |
| 1367 | composite | LimbBackend | 0.001 | `9981cee27cf2d0f0` | no | no |
| 1373 | composite | LimbBackend | 0.001 | `926b723ed980dddb` | no | no |
| 1381 | composite | LimbBackend | 0.001 | `7de9e65bcc54f217` | no | no |
| 1399 | composite | LimbBackend | 0.001 | `4170d6113a30eb26` | no | no |
| 1409 | composite | LimbBackend | 0.002 | `56d09598abe39e50` | no | no |
| 1423 | composite | LimbBackend | 0.002 | `945c75f584291bf3` | no | no |
| 1427 | composite | LimbBackend | 0.001 | `1152365e90a06a62` | no | no |
| 1429 | composite | LimbBackend | 0.001 | `d0192fff1ea99bcd` | no | no |
| 1433 | composite | LimbBackend | 0.001 | `e535e340d1a540a7` | no | no |
| 1439 | composite | LimbBackend | 0.001 | `1c967dce6931bdfc` | no | no |
| 1447 | composite | LimbBackend | 0.002 | `11e127e29b9cc508` | no | no |
| 1451 | composite | LimbBackend | 0.002 | `1c65e51b6b9bf930` | no | no |
| 1453 | composite | LimbBackend | 0.002 | `0c0e18052d422a15` | no | no |
| 1459 | composite | LimbBackend | 0.002 | `fffc43364af15d3e` | no | no |
| 1471 | composite | LimbBackend | 0.002 | `ca464b0f2bb0c7e1` | no | no |
| 1481 | composite | LimbBackend | 0.002 | `d20789648ea4aa2a` | no | no |
| 1483 | composite | LimbBackend | 0.002 | `143801aba7b8d471` | no | no |
| 1487 | composite | LimbBackend | 0.002 | `08fbc7e38899f172` | no | no |
| 1489 | composite | LimbBackend | 0.002 | `55fb4ae078f2c572` | no | no |
| 1493 | composite | LimbBackend | 0.002 | `604c51c4d924867b` | no | no |
| 1499 | composite | LimbBackend | 0.002 | `099ab1ac702b8e51` | no | no |
| 1511 | composite | LimbBackend | 0.002 | `326f4be24a327967` | no | no |
| 1523 | composite | LimbBackend | 0.002 | `f5881926caf57040` | no | no |
| 1531 | composite | LimbBackend | 0.002 | `73dc49f8ec4cda47` | no | no |
| 1543 | composite | LimbBackend | 0.002 | `6736ac8bfb945335` | no | no |
| 1549 | composite | LimbBackend | 0.002 | `09484baf6acf54bb` | no | no |
| 1553 | composite | LimbBackend | 0.002 | `bd46bda540b40f11` | no | no |
| 1559 | composite | LimbBackend | 0.002 | `04046f80ccf94c8a` | no | no |
| 1567 | composite | LimbBackend | 0.002 | `f0786f2d93a80578` | no | no |
| 1571 | composite | LimbBackend | 0.002 | `d192891b0cdc697c` | no | no |
| 1579 | composite | LimbBackend | 0.002 | `3fc35bf7ae28bc34` | no | no |
| 1583 | composite | LimbBackend | 0.002 | `8c0f0f422ff82d4f` | no | no |
| 1597 | composite | LimbBackend | 0.002 | `99d3294a5368c8b6` | no | no |
| 1601 | composite | LimbBackend | 0.002 | `630cb3ecb11a446c` | no | no |
| 1607 | composite | LimbBackend | 0.002 | `74391053e73e104c` | no | no |
| 1609 | composite | LimbBackend | 0.002 | `39d5c6535bb4206c` | no | no |
| 1613 | composite | LimbBackend | 0.002 | `275bb0b0cadd9418` | no | no |
| 1619 | composite | LimbBackend | 0.002 | `3f964611757ce4e0` | no | no |
| 1621 | composite | LimbBackend | 0.002 | `a4b6578f5fa02147` | no | no |
| 1627 | composite | LimbBackend | 0.002 | `41d049488bed49d6` | no | no |
| 1637 | composite | LimbBackend | 0.002 | `77a67ad9262cc6d9` | no | no |
| 1657 | composite | LimbBackend | 0.002 | `3ccd6323222bdfae` | no | no |
| 1663 | composite | LimbBackend | 0.002 | `f6691c8f6632468a` | no | no |
| 1667 | composite | LimbBackend | 0.003 | `0b12b8d91b78630c` | no | no |
| 1669 | composite | LimbBackend | 0.003 | `56d373351121be8f` | no | no |
| 1693 | composite | LimbBackend | 0.003 | `0dce3b3c3f517154` | no | no |
| 1697 | composite | LimbBackend | 0.003 | `3308e4b4d3085a8f` | no | no |
| 1699 | composite | LimbBackend | 0.003 | `f07d25612216c5e8` | no | no |
| 1709 | composite | LimbBackend | 0.003 | `08fce14e77b01a95` | no | no |
| 1721 | composite | LimbBackend | 0.003 | `e3bd84d4b6317686` | no | no |
| 1723 | composite | LimbBackend | 0.003 | `7374ba216e181940` | no | no |
| 1733 | composite | LimbBackend | 0.003 | `f1e125562aef64e4` | no | no |
| 1741 | composite | LimbBackend | 0.003 | `c490ebddc981ebef` | no | no |
| 1747 | composite | LimbBackend | 0.003 | `c89f27286a1fded2` | no | no |
| 1753 | composite | LimbBackend | 0.003 | `a984d3ca0516ec2d` | no | no |
| 1759 | composite | LimbBackend | 0.003 | `90c7a1398b2c240f` | no | no |
| 1777 | composite | LimbBackend | 0.003 | `21ff19bd546cff27` | no | no |
| 1783 | composite | LimbBackend | 0.003 | `180138b6c5c41ab5` | no | no |
| 1787 | composite | LimbBackend | 0.003 | `3c16c5e200dc85f7` | no | no |
| 1789 | composite | LimbBackend | 0.003 | `30670272690b4cb3` | no | no |
| 1801 | composite | LimbBackend | 0.003 | `8d42ef0dab27a38f` | no | no |
| 1811 | composite | LimbBackend | 0.003 | `61a8abd9af0cb711` | no | no |
| 1823 | composite | LimbBackend | 0.003 | `b7906a56996fb640` | no | no |
| 1831 | composite | LimbBackend | 0.003 | `6a04cdbb6fd55851` | no | no |
| 1847 | composite | LimbBackend | 0.004 | `3f188378bca5baf6` | no | no |
| 1861 | composite | LimbBackend | 0.004 | `13c03203698a719e` | no | no |
| 1867 | composite | LimbBackend | 0.004 | `ea1ed0d635a25244` | no | no |
| 1871 | composite | LimbBackend | 0.005 | `b6f151e89f8893e6` | no | no |
| 1873 | composite | LimbBackend | 0.005 | `5c72830093137e52` | no | no |
| 1877 | composite | LimbBackend | 0.004 | `405c0cd115e47f10` | no | no |
| 1879 | composite | LimbBackend | 0.003 | `e0296f6671d88fa4` | no | no |
| 1889 | composite | LimbBackend | 0.003 | `87a9ee3daffdc5be` | no | no |
| 1901 | composite | LimbBackend | 0.003 | `0e169ae0c4bbb885` | no | no |
| 1907 | composite | LimbBackend | 0.003 | `b77f873b9ba3f71d` | no | no |
| 1913 | composite | LimbBackend | 0.003 | `1aa30e96ebfddb64` | no | no |
| 1931 | composite | LimbBackend | 0.004 | `cca8369587fde300` | no | no |
| 1933 | composite | LimbBackend | 0.004 | `44ee59e4e3faef61` | no | no |
| 1949 | composite | LimbBackend | 0.004 | `4840411a7fe27d2f` | no | no |
| 1951 | composite | LimbBackend | 0.004 | `9de4c4cc0fd7ce53` | no | no |
| 1973 | composite | LimbBackend | 0.004 | `b4fe518d237454ba` | no | no |
| 1979 | composite | LimbBackend | 0.004 | `90ca7da41af138b1` | no | no |
| 1987 | composite | LimbBackend | 0.004 | `d1e2bf9754431537` | no | no |
| 1993 | composite | LimbBackend | 0.004 | `cedfd87e807d714d` | no | no |
| 1997 | composite | LimbBackend | 0.004 | `8fe53be7688cae75` | no | no |
| 1999 | composite | LimbBackend | 0.004 | `1eab21224a18b5fe` | no | no |
| 2003 | composite | LimbBackend | 0.004 | `fa6922742d975f44` | no | no |
| 2011 | composite | LimbBackend | 0.004 | `838fe0ed54f1ff0e` | no | no |
| 2017 | composite | LimbBackend | 0.004 | `95dc16f05fd5b137` | no | no |
| 2027 | composite | LimbBackend | 0.004 | `3eb20e694b09f91f` | no | no |
| 2029 | composite | LimbBackend | 0.004 | `caa46606e0863289` | no | no |
| 2039 | composite | LimbBackend | 0.004 | `e4b185ef0417de88` | no | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645051290
