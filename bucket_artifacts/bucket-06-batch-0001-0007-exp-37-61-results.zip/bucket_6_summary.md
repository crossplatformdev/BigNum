# Bucket 6 Summary

- **Range**: [32, 63]
- **Total tested**: 7
- **Primes**: 1 (known: 1, new: 0)
- **Composites**: 6
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (1)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 61 | GenericBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 37 | composite | GenericBackend | 0.000 | `0000001b435853c0` | no | no |
| 41 | composite | GenericBackend | 0.000 | `000000c771a34e19` | no | no |
| 43 | composite | GenericBackend | 0.000 | `000005407522fc59` | no | no |
| 47 | composite | GenericBackend | 0.000 | `000057f28cacb060` | no | no |
| 53 | composite | GenericBackend | 0.000 | `0014a4aa2af1c57d` | no | no |
| 59 | composite | GenericBackend | 0.000 | `064099e5fcbcaf36` | no | no |
| 61 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
