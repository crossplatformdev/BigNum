# Bucket 7 Summary

- **Range**: [64, 127]
- **Total tested**: 13
- **Primes**: 3 (known: 3, new: 0)
- **Composites**: 10
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (3)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 89 | GenericBackend | 0.000 | `0000000000000000` |
| 107 | GenericBackend | 0.000 | `0000000000000000` |
| 127 | GenericBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 67 | composite | GenericBackend | 0.000 | `677d24ee8ae3b2c2` | no | no |
| 71 | composite | GenericBackend | 0.000 | `bb737b29d59e0c94` | no | no |
| 73 | composite | GenericBackend | 0.000 | `779075a783edad63` | no | no |
| 79 | composite | GenericBackend | 0.000 | `a607b2841fcfb77a` | no | no |
| 83 | composite | GenericBackend | 0.000 | `9554413a9271c592` | no | no |
| 89 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |
| 97 | composite | GenericBackend | 0.000 | `f5de17c663a867fb` | no | no |
| 101 | composite | GenericBackend | 0.000 | `d0dd748dd7817436` | no | no |
| 103 | composite | GenericBackend | 0.000 | `55099688aa375b3e` | no | no |
| 107 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |
| 109 | composite | GenericBackend | 0.000 | `288be38a641f9f62` | no | no |
| 113 | composite | GenericBackend | 0.000 | `780ea2b2e6916cf9` | no | no |
| 127 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
