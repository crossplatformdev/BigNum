# Bucket 9 Summary

- **Range**: [256, 511]
- **Total tested**: 43
- **Primes**: 0 (known: 0, new: 0)
- **Composites**: 43
- **Total time**: 0.003 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (0)

_None in this bucket._

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 257 | composite | LimbBackend | 0.000 | `7addc59710433aa8` | no | no |
| 263 | composite | LimbBackend | 0.000 | `4c127f3f637e74f5` | no | no |
| 269 | composite | LimbBackend | 0.000 | `fe685798d6a74346` | no | no |
| 271 | composite | LimbBackend | 0.000 | `cad20a329f696ee9` | no | no |
| 277 | composite | LimbBackend | 0.000 | `f58a0efa29c9342f` | no | no |
| 281 | composite | LimbBackend | 0.000 | `2846f8f3e9ca9890` | no | no |
| 283 | composite | LimbBackend | 0.000 | `c3f963b67a10e105` | no | no |
| 293 | composite | LimbBackend | 0.000 | `e9db602a3df0f97a` | no | no |
| 307 | composite | LimbBackend | 0.000 | `e1058f6016bdc19d` | no | no |
| 311 | composite | LimbBackend | 0.000 | `f059ea4e3a4cb2c6` | no | no |
| 313 | composite | LimbBackend | 0.000 | `cc8fce998b3704a6` | no | no |
| 317 | composite | LimbBackend | 0.000 | `f9df7dd0408ecde3` | no | no |
| 331 | composite | LimbBackend | 0.000 | `b9367d4722287e7d` | no | no |
| 337 | composite | LimbBackend | 0.000 | `46ba11016d523d69` | no | no |
| 347 | composite | LimbBackend | 0.000 | `52fdafcd6b5d7c3e` | no | no |
| 349 | composite | LimbBackend | 0.000 | `bc6900aa79c3ee7f` | no | no |
| 353 | composite | LimbBackend | 0.000 | `d491425a05b0122b` | no | no |
| 359 | composite | LimbBackend | 0.000 | `40b1c2ad839527b8` | no | no |
| 367 | composite | LimbBackend | 0.000 | `b9a757b0a06c672e` | no | no |
| 373 | composite | LimbBackend | 0.000 | `556357346e16ef51` | no | no |
| 379 | composite | LimbBackend | 0.000 | `bf657d7261f5b4c9` | no | no |
| 383 | composite | LimbBackend | 0.000 | `635a6a101586d372` | no | no |
| 389 | composite | LimbBackend | 0.000 | `faa6202de781985d` | no | no |
| 397 | composite | LimbBackend | 0.000 | `e1eb3fa2154bbcbb` | no | no |
| 401 | composite | LimbBackend | 0.000 | `9eb0a7845f35a1d1` | no | no |
| 409 | composite | LimbBackend | 0.000 | `6487b36da3bfcade` | no | no |
| 419 | composite | LimbBackend | 0.000 | `aa68e3d3ba608b9c` | no | no |
| 421 | composite | LimbBackend | 0.000 | `2a7cbab3b35df88e` | no | no |
| 431 | composite | LimbBackend | 0.000 | `f8d9c2bf2b6aee92` | no | no |
| 433 | composite | LimbBackend | 0.000 | `a33da55ca82f4a88` | no | no |
| 439 | composite | LimbBackend | 0.000 | `a8815151d30f8d9e` | no | no |
| 443 | composite | LimbBackend | 0.000 | `e7be46b4c89b4072` | no | no |
| 449 | composite | LimbBackend | 0.000 | `beb16014e8772748` | no | no |
| 457 | composite | LimbBackend | 0.000 | `3b2911d9e14a0b80` | no | no |
| 461 | composite | LimbBackend | 0.000 | `380015d33a01ff1f` | no | no |
| 463 | composite | LimbBackend | 0.000 | `91451807ac90d3dd` | no | no |
| 467 | composite | LimbBackend | 0.000 | `0c48a5da56f3a40f` | no | no |
| 479 | composite | LimbBackend | 0.000 | `e1076da917c22c95` | no | no |
| 487 | composite | LimbBackend | 0.000 | `c84aa75515ed69c7` | no | no |
| 491 | composite | LimbBackend | 0.000 | `bc5097b7d340187c` | no | no |
| 499 | composite | LimbBackend | 0.000 | `855ebaf3e1232715` | no | no |
| 503 | composite | LimbBackend | 0.000 | `3dd63406bbedfebd` | no | no |
| 509 | composite | LimbBackend | 0.000 | `9c10c9ea2bb210cd` | no | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645051290
