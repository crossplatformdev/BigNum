# Bucket 4 Summary

- **Range**: [8, 15]
- **Total tested**: 2
- **Primes**: 1 (known: 1, new: 0)
- **Composites**: 1
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (1)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 13 | GenericBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 11 | composite | GenericBackend | 0.000 | `00000000000006c8` | no | no |
| 13 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
