# Bucket 3 Summary

- **Range**: [4, 7]
- **Total tested**: 2
- **Primes**: 2 (known: 2, new: 0)
- **Composites**: 0
- **Total time**: 0.000 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (2)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 5 | GenericBackend | 0.000 | `0000000000000000` |
| 7 | GenericBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 5 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |
| 7 | prime | GenericBackend | 0.000 | `0000000000000000` | yes | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645042817
