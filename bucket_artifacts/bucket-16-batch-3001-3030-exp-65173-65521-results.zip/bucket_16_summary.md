# Bucket 16 Summary

- **Range**: [32768, 65535]
- **Total tested**: 30
- **Primes**: 0 (known: 0, new: 0)
- **Composites**: 30
- **Total time**: 166.008 s
- **Avg time**: 5.534 s/exponent

## Verified Known Mersenne Primes (0)

_None in this bucket._

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 65173 | composite | FftMersenneBackend | 5.418 | `68026a969609277d` | no | no |
| 65179 | composite | FftMersenneBackend | 5.411 | `bd1f5ee3cfc0a913` | no | no |
| 65183 | composite | FftMersenneBackend | 5.397 | `92832e6c972a3dca` | no | no |
| 65203 | composite | FftMersenneBackend | 5.542 | `393a2bf85644ff71` | no | no |
| 65213 | composite | FftMersenneBackend | 5.439 | `aa802f65241b9728` | no | no |
| 65239 | composite | FftMersenneBackend | 5.422 | `18a30e9cb3f65274` | no | no |
| 65257 | composite | FftMersenneBackend | 5.468 | `4960011ee7591d5a` | no | no |
| 65267 | composite | FftMersenneBackend | 5.499 | `b9159bc591118e5a` | no | no |
| 65269 | composite | FftMersenneBackend | 5.428 | `35e2524b58da0e73` | no | no |
| 65287 | composite | FftMersenneBackend | 5.555 | `21d9e758dab9c00a` | no | no |
| 65293 | composite | FftMersenneBackend | 5.435 | `446c7cbdb07de7c9` | no | no |
| 65309 | composite | FftMersenneBackend | 5.426 | `5fe68aa5e3a1c75d` | no | no |
| 65323 | composite | FftMersenneBackend | 5.458 | `921966eb0d2bc24c` | no | no |
| 65327 | composite | FftMersenneBackend | 5.495 | `61a2841354a75a05` | no | no |
| 65353 | composite | FftMersenneBackend | 5.481 | `4262dc459bc95205` | no | no |
| 65357 | composite | FftMersenneBackend | 5.539 | `91097bd468d7b8d8` | no | no |
| 65371 | composite | FftMersenneBackend | 5.505 | `01f8384456f03046` | no | no |
| 65381 | composite | FftMersenneBackend | 5.583 | `751202c1c7f44d71` | no | no |
| 65393 | composite | FftMersenneBackend | 5.619 | `c3a6563678eb557e` | no | no |
| 65407 | composite | FftMersenneBackend | 5.616 | `9d91fae217b25dd0` | no | no |
| 65413 | composite | FftMersenneBackend | 5.618 | `4ce61a0d61a544f4` | no | no |
| 65419 | composite | FftMersenneBackend | 5.618 | `2036e2f7e7c10276` | no | no |
| 65423 | composite | FftMersenneBackend | 5.618 | `420d87ec1f265a02` | no | no |
| 65437 | composite | FftMersenneBackend | 5.628 | `b004b54a4f48969e` | no | no |
| 65447 | composite | FftMersenneBackend | 5.646 | `3c2e5f30844adfad` | no | no |
| 65449 | composite | FftMersenneBackend | 5.625 | `fea8d1c69e9296eb` | no | no |
| 65479 | composite | FftMersenneBackend | 5.625 | `73ac579aaee495a4` | no | no |
| 65497 | composite | FftMersenneBackend | 5.639 | `ca7a18466e7f6532` | no | no |
| 65519 | composite | FftMersenneBackend | 5.626 | `f39f5be7c4552b52` | no | no |
| 65521 | composite | FftMersenneBackend | 5.628 | `f120ae1ca611fe2a` | no | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645051290
