# Bucket 10 Summary

- **Range**: [512, 1023]
- **Total tested**: 75
- **Primes**: 2 (known: 2, new: 0)
- **Composites**: 73
- **Total time**: 0.028 s
- **Avg time**: 0.000 s/exponent

## Verified Known Mersenne Primes (2)

| Exponent | Backend | Elapsed (s) | Residue |
|----------|---------|-------------|--------|
| 521 | LimbBackend | 0.000 | `0000000000000000` |
| 607 | LimbBackend | 0.000 | `0000000000000000` |

## New Mersenne Prime Discoveries (0)

_None in this bucket._

## All Tested Exponents

| Exponent | Result | Backend | Elapsed (s) | Residue | Known | New |
|----------|--------|---------|-------------|---------|-------|-----|
| 521 | prime | LimbBackend | 0.000 | `0000000000000000` | yes | no |
| 523 | composite | LimbBackend | 0.000 | `42154e4ab2f76faf` | no | no |
| 541 | composite | LimbBackend | 0.000 | `c59f3980d8572aab` | no | no |
| 547 | composite | LimbBackend | 0.000 | `6b7fb16a7301e2be` | no | no |
| 557 | composite | LimbBackend | 0.000 | `caaa6269a9b4c92e` | no | no |
| 563 | composite | LimbBackend | 0.000 | `0521b665b3d47a3f` | no | no |
| 569 | composite | LimbBackend | 0.000 | `e49e986af1a15f67` | no | no |
| 571 | composite | LimbBackend | 0.000 | `2a56e2736dba2c5c` | no | no |
| 577 | composite | LimbBackend | 0.000 | `87dc3bbb1d5dfa8e` | no | no |
| 587 | composite | LimbBackend | 0.000 | `0f88ee7f3bd8fb20` | no | no |
| 593 | composite | LimbBackend | 0.000 | `787fcef355547465` | no | no |
| 599 | composite | LimbBackend | 0.000 | `6a833f78b018daa5` | no | no |
| 601 | composite | LimbBackend | 0.000 | `2345f7bd0f9d7636` | no | no |
| 607 | prime | LimbBackend | 0.000 | `0000000000000000` | yes | no |
| 613 | composite | LimbBackend | 0.000 | `232e16c243f62b3c` | no | no |
| 617 | composite | LimbBackend | 0.000 | `72cd3735ba3d3be9` | no | no |
| 619 | composite | LimbBackend | 0.000 | `d52ef02f0563f036` | no | no |
| 631 | composite | LimbBackend | 0.000 | `2669c07ed355dec3` | no | no |
| 641 | composite | LimbBackend | 0.000 | `bc44c46e332cccc7` | no | no |
| 643 | composite | LimbBackend | 0.000 | `ba91638834cc623b` | no | no |
| 647 | composite | LimbBackend | 0.000 | `d7ec313863a5f8e8` | no | no |
| 653 | composite | LimbBackend | 0.000 | `01487515a67e637d` | no | no |
| 659 | composite | LimbBackend | 0.000 | `6d293dce69fa55ed` | no | no |
| 661 | composite | LimbBackend | 0.000 | `e94bf837bb605116` | no | no |
| 673 | composite | LimbBackend | 0.000 | `111c03328d18a8e8` | no | no |
| 677 | composite | LimbBackend | 0.000 | `2f701b70b5180848` | no | no |
| 683 | composite | LimbBackend | 0.000 | `d5c5a65bd12f207c` | no | no |
| 691 | composite | LimbBackend | 0.000 | `95d57f47c73b4dc4` | no | no |
| 701 | composite | LimbBackend | 0.000 | `ae3444058275b4af` | no | no |
| 709 | composite | LimbBackend | 0.000 | `9acbf79ffd36ada3` | no | no |
| 719 | composite | LimbBackend | 0.000 | `18fd3af6962fa67d` | no | no |
| 727 | composite | LimbBackend | 0.000 | `207444900452e0ff` | no | no |
| 733 | composite | LimbBackend | 0.000 | `b31d3fcb37697e8c` | no | no |
| 739 | composite | LimbBackend | 0.000 | `ed5ff70fb83bda35` | no | no |
| 743 | composite | LimbBackend | 0.000 | `7c565a4205c5e380` | no | no |
| 751 | composite | LimbBackend | 0.000 | `c0e675aa52994789` | no | no |
| 757 | composite | LimbBackend | 0.000 | `48122229cb2f2518` | no | no |
| 761 | composite | LimbBackend | 0.000 | `db26bf7532d11906` | no | no |
| 769 | composite | LimbBackend | 0.000 | `2413baaa104a2c09` | no | no |
| 773 | composite | LimbBackend | 0.000 | `7d90e36d0fcaf677` | no | no |
| 787 | composite | LimbBackend | 0.000 | `3e00d93d86f39e25` | no | no |
| 797 | composite | LimbBackend | 0.000 | `9380ce57f8645aa4` | no | no |
| 809 | composite | LimbBackend | 0.000 | `4709b49b771bddde` | no | no |
| 811 | composite | LimbBackend | 0.001 | `b7b5192d72f877b9` | no | no |
| 821 | composite | LimbBackend | 0.000 | `221d358d6affdc0f` | no | no |
| 823 | composite | LimbBackend | 0.000 | `a0de2b47dd409212` | no | no |
| 827 | composite | LimbBackend | 0.000 | `f69fcfc33ee21610` | no | no |
| 829 | composite | LimbBackend | 0.000 | `3994a6a6775d76d8` | no | no |
| 839 | composite | LimbBackend | 0.001 | `acda35fb77d7d289` | no | no |
| 853 | composite | LimbBackend | 0.001 | `ad1fbf68af6a4d0c` | no | no |
| 857 | composite | LimbBackend | 0.001 | `d9385187c05f3429` | no | no |
| 859 | composite | LimbBackend | 0.001 | `260d86ec69f38cc6` | no | no |
| 863 | composite | LimbBackend | 0.001 | `3ec2e7bc3002c1df` | no | no |
| 877 | composite | LimbBackend | 0.001 | `4f8ce4b3575fc4bf` | no | no |
| 881 | composite | LimbBackend | 0.001 | `d05974be43f7448a` | no | no |
| 883 | composite | LimbBackend | 0.001 | `6f4b95e1c1ef74d0` | no | no |
| 887 | composite | LimbBackend | 0.001 | `44e69c2bb4bbbcbf` | no | no |
| 907 | composite | LimbBackend | 0.001 | `43f7589059a6e583` | no | no |
| 911 | composite | LimbBackend | 0.001 | `fe1fcb4dcbd47987` | no | no |
| 919 | composite | LimbBackend | 0.001 | `d6b67f68183de4d5` | no | no |
| 929 | composite | LimbBackend | 0.001 | `3f6d09c5c2da8e6e` | no | no |
| 937 | composite | LimbBackend | 0.001 | `626298ef2bb9b854` | no | no |
| 941 | composite | LimbBackend | 0.001 | `f33126546d389898` | no | no |
| 947 | composite | LimbBackend | 0.001 | `4d6ec1498942f30e` | no | no |
| 953 | composite | LimbBackend | 0.001 | `5b5a75b028646983` | no | no |
| 967 | composite | LimbBackend | 0.001 | `816256f1069f8623` | no | no |
| 971 | composite | LimbBackend | 0.001 | `f366174a235bf2b2` | no | no |
| 977 | composite | LimbBackend | 0.001 | `bc602456266f780b` | no | no |
| 983 | composite | LimbBackend | 0.001 | `a5935fe444050e6b` | no | no |
| 991 | composite | LimbBackend | 0.001 | `c924ff59f1be594c` | no | no |
| 997 | composite | LimbBackend | 0.001 | `8c75910c80b3ace3` | no | no |
| 1009 | composite | LimbBackend | 0.001 | `5c0842eaa6df00c6` | no | no |
| 1013 | composite | LimbBackend | 0.001 | `3a7ccf535999fdf8` | no | no |
| 1019 | composite | LimbBackend | 0.001 | `773573f489edda3f` | no | no |
| 1021 | composite | LimbBackend | 0.001 | `080bc5bb21226bf8` | no | no |

**Workflow run:** https://github.com/crossplatformdev/BigNum/actions/runs/22645051290
